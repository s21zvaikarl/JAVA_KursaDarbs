package lv.venta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMd21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
