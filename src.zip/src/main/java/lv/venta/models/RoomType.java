package lv.venta.models;

public enum RoomType {
	single, doubleEco, doubleLux, presidental
}
