package lv.venta.models;

public enum HotelServiceType {
	pool, spa, roomservice, gym, other
}
