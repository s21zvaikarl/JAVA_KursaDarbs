package lv.venta.models;

public enum EmployeePosition {
	receptionist, concierge, chef, bartender, housekeeper, manager, sales, hr, massager, lifeguard, security
}
